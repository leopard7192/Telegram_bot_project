#!/bin/bash
python3 telegram_price_bot.py
