import time
import threading
import requests
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes

API_KEY = "FreelcJny6VBNathhjqBpai3J8OtIaiA"
BOT_TOKEN = "7512564701:AAFEnEV_gp8JT3PXjuQ5vTkCLZHVf865z2k"

user_configs = {}
checking = {}

def fetch_prices():
    url = f"https://BrsApi.ir/Api/Tsetmc/AllSymbols.php?key={API_KEY}&type=Number"
    try:
        res = requests.get(url)
        return res.json()
    except:
        return []

def find_price(symbol, data):
    for item in data:
        if item["l18"] == symbol:
            return item.get("pl")
    return None

def checker_loop(user_id, bot):
    while checking.get(user_id):
        data = fetch_prices()
        for pair in user_configs.get(user_id, []):
            sym1, sym2, threshold = pair["s1"], pair["s2"], pair["t"]
            p1 = find_price(sym1, data)
            p2 = find_price(sym2, data)
            if p1 is not None and p2 is not None:
                if abs(p1 - p2) >= threshold:
                    bot.send_message(chat_id=user_id, text=f"📢 اختلاف {sym1} و {sym2} به {abs(p1 - p2)} رسید!")
        time.sleep(180)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("سلام! با دستور /add یک جفت سهم وارد کن. مثل:\n/add شستا فولاد 10")

async def add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        s1, s2, t = context.args[0], context.args[1], int(context.args[2])
        user_id = update.message.chat_id
        user_configs.setdefault(user_id, []).append({"s1": s1, "s2": s2, "t": t})
        await update.message.reply_text(f"✅ جفت {s1} و {s2} با آستانه {t} ثبت شد.")
    except:
        await update.message.reply_text("❌ فرمت اشتباه! مثال: /add شستا فولاد 10")

async def enable(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.chat_id
    if not checking.get(user_id):
        checking[user_id] = True
        threading.Thread(target=checker_loop, args=(user_id, context.bot), daemon=True).start()
        await update.message.reply_text("✅ بررسی فعال شد.")
    else:
        await update.message.reply_text("⏳ بررسی در حال اجراست.")

async def disable(update: Update, context: ContextTypes.DEFAULT_TYPE):
    checking[update.message.chat_id] = False
    await update.message.reply_text("⛔ بررسی غیرفعال شد.")

async def list_pairs(update: Update, context: ContextTypes.DEFAULT_TYPE):
    confs = user_configs.get(update.message.chat_id, [])
    if confs:
        msg = "\n".join([f"{c['s1']} - {c['s2']} (آستانه: {c['t']})" for c in confs])
        await update.message.reply_text("📋 جفت‌های فعال:\n" + msg)
    else:
        await update.message.reply_text("📭 جفت فعالی تعریف نشده.")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("add", add))
app.add_handler(CommandHandler("enable", enable))
app.add_handler(CommandHandler("disable", disable))
app.add_handler(CommandHandler("list", list_pairs))

app.run_polling()
